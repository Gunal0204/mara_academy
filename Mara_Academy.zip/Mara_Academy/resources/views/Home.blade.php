<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mara Academy</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    @keyframes slide-in-fade {
      0% {
        transform: translateX(-100%);
        opacity: 0;
      }
      50% {
        opacity: 0.5;
      }
      100% {
        transform: translateX(0);
        opacity: 1;
      }
    }


    .sliding-text {
      margin-top: 15%;
      display: inline-block;
      animation: slide-in-fade 3s ease-out forwards;
      font-size: 2.5rem;
      font-weight: bold;
      color: #fff;
      text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
      white-space: nowrap; /* Prevent text from wrapping */
      overflow: hidden; /* Hide overflowing text */
      max-width: 100%; /* Ensure it stays within container */
    }

    .button-row {
      display: flex;
      justify-content: space-around;
      margin-top: 5rem;
    }

    .carousel-inner img {
      height: 500px;
      object-fit: cover;
    }

    .image-row {
      display: flex;
      justify-content: space-around;
      margin-top: 2rem;
    }

    .image-row img {
      width: 30%;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .button-group {
      margin-top: 1rem;
      display: flex;
    }

    .horizontal-buttons {
      margin-top: 2rem;
      text-align: center;
    }





    /* Floating Navbar */
    .navbar {
      position: fixed;
      top: 30px;
      left: 50%;
      transform: translateX(-50%); /* Center navbar */
      width: 95%; /* Set the width to 80% of the screen */
      z-index: 1000;
      background-color: rgba(255, 255, 255, 0.9); /* Optional: Semi-transparent white */
      backdrop-filter: blur(5px); /* Optional: Adds blur effect */
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Optional: Adds a slight shadow */
    }

    /* Body padding to prevent content from hiding behind the navbar */
    body {
      padding-top: 0px; /* Adjust for navbar height */
    }

    /*payment video section  */

    /* Video Section */
.video-section {
  text-align: center;
  padding: 40px 20px;

  border-radius: 10px;
  margin-top: 50px;
}

/* Adjust iframe styles */
.video-section iframe {
  border-radius: 10px;
  border: none;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
  transition: all 0.3s ease;
}

/* Hover effect on iframe */
.video-section iframe:hover {
  transform: scale(1.05);
}

/* Adjusting responsiveness for iframe */
@media (max-width: 768px) {
  .video-section iframe {
    width: 100%;
    height: 250px;  /* Adjust height for smaller screens */
  }
}

.video-section p {
  font-size: 18px;
  color: #333;
  margin-bottom: 20px;
}

.video-section strong {
  color: #000;
}


/* Carousel item with background image */
.carousel-item {
  background-size: cover;
  background-position: center;
  height: 500px; /* Adjust this height as necessary */
}

/* Add this class to your hero-bg section */
.hero-bg {
  background: rgba(0, 0, 0, 0.5); /* Optional: add overlay effect */
}

  </style>
</head>
<body>

   <!-- Floating Navbar -->

   <nav class="navbar navbar-expand-sm navbar-light rounded">
    <div class="container-fluid">
      <img src="C:\xampp\htdocs\M_academy\saxophone.png" alt="Logo" style="width:40px; height: 40px;">
      <p class="ms-4">Mara Music Academy</p>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="/home" style="color: rgb(47, 50, 79);">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/home/courses" style="color: rgb(47, 50, 79);">Courses</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/home/student_Reg" style="color: rgb(47, 50, 79);">Register</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/home/contact" style="color: rgb(47, 50, 79);">Contact Us</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>


 
  <!-- Carousel -->
<header class="hero-bg text-white text-center py-5">
  <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
    <div class="carousel-inner">
      <div class="carousel-item active" style="background-image: url('{{ asset('images/Flute_son.jpeg') }}'); background-size: cover; background-position: center; height: 500px;">
        <div class="container">
          <h1 class="sliding-text">Mara Music Academy</h1>
        </div>
      </div>
      <div class="carousel-item" style="background-image: url('{{ asset('images/baby_guitar.jpeg') }}'); background-size: cover; background-position: center; height: 500px;">
        <div class="container">
          <h1 class="sliding-text">Discover Our Services</h1>
        </div>
      </div>
      <div class="carousel-item" style="background-image: url('{{ asset('images/Guitar_Father.jpeg') }}'); background-size: cover; background-position: center; height: 500px;">
        <div class="container">
          <h1 class="sliding-text">Join Our Community</h1>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
  <div class="container">
    <div class="button-row">
      <a href="/home/student_Login" class="btn btn-lg border border-radius-1 text text-white fs-6">Student Login</a>
    </div>
  </div>
</header>



  <!-- Payment Guide Video Section -->
<div class="video-section">
  <p>Kindly watch the video below. It helps you learn how to pay the fee...</p>
  
  <div class="iframe-container">
    <iframe width="560" height="315" 
      src="https://www.youtube.com/embed/5WsUIeNAtbM?si=wtTYnXzrj3xRQJ9x" 
      title="YouTube video player" 
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
      referrerpolicy="strict-origin-when-cross-origin" 
      allowfullscreen>
    </iframe>
  </div>

  <p class="mt-3">For any issues with login or payment, contact us via WhatsApp at <strong>9940814845</strong>.</p>
</div>


  <!--Demo class -->

  <div class="container-fluid py-5">
    <h1 class="text-center" style="color: rgb(68, 71, 99);">Demo Classes</h1>
    <ul class="list-group list-group-flush list-group-horizontal-md justify-content-center">
      <li class="list-group-item list-group-item-action border-0 text-center">
        KeyBoard Demo Classes
        <span class="badge bg-danger rounded-pill ms-2">Free</span>
      </li>
      <li class="list-group-item list-group-item-action border-0 text-center">
        Flute Demo Classes
        <span class="badge bg-danger rounded-pill ms-2">Free</span>
      </li>
    </ul>
  </div>


  <!--contact us-->

  <div class="container-fluid " style="background-color: #ecebeb;">
    <h1 class="text-center py-5 "style="color: rgb(68, 71, 99);">Contact Us</h1>

    <div class="container p-4 ">
      <div class="row justify-content-center">
        <div class="col-md-6 col-sm-12">
          <div class="card shadow-sm" >
            <div class="card-body">
              <form action="" method="post">
                <div class="mb-3">
                  <label for="name" class="form-label text-dark">Name:</label>
                  <input type="text" class="form-control" id="name" name="Name" placeholder="Enter your name" required>
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label text-dark">Email address:</label>
                  <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="mb-3">
                  <label for="message" class="form-label text-dark">Message:</label>
                  <textarea class="form-control" id="message" rows="4" name="message" placeholder="Enter your message"
                    required></textarea>
                </div>
                <button type="submit" class="btn btn-dark"style="margin-left: 45%;">Submit</button>
                @csrf
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
 
   <!-- Footer Section -->
  <footer class="container-fluid bg-dark text-white py-5" style="background: linear-gradient(45deg,rgba(11, 16, 21, 0.83),rgba(75, 3, 99, 0.3));">
    <div class="row">
      <div class="col-12 col-sm-4 text-center">
        <h5>About Us</h5>
        <p>
          Edit this section with information about your academy. Add details such as your mission, vision, and history.
        </p>
      </div>
      <div class="col-12 col-sm-4 text-center">
        <h5>Quick Links</h5>
        <ul class="list-unstyled">
          <li><a href="#" class="text-white text-decoration-none">Home</a></li>
          <li><a href="#" class="text-white text-decoration-none">Courses</a></li>
          <li><a href="#" class="text-white text-decoration-none">Contact Us</a></li>
          <li><a href="#" class="text-white text-decoration-none">FAQ</a></li>
        </ul>
      </div>
      <div class="col-12 col-sm-4 text-center">
        <h5>Contact Us</h5>
        <p>
          Address: Your Academy Address<br>
          Phone: (+123) 456-7890<br>
          Email: info@academy.com
        </p>
      </div>
    </div>
    <div class="row justify-content-center">
      <div class="col-auto">
        <p class="mb-0">© 2025 Your Academy. All rights reserved.</p>
      </div>
    </div>
  </footer>








  <!--script for bootstrap-->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>

</html>




<!-- MOdel 1     //our courses

<div class="container-fluid mt-0" style="background-color: #ecebeb">

    <h1 class="text" style="color:  rgb(47, 50, 79);">Our Courses</h1>

    <div class="container-fluid mt-5">
      <div class="row mb-5">
        <div class="col col-sm-2 col-md-6 col-lg-4 d-flex d-flex-start">
          <img src="C:\xampp\htdocs\M_academy\view-piano-guitar-musical-instruments-store.jpg"
            style="width: 300px;  height: 180px;">
        </div>
        <div class="col mt-5 col-sm-2 col-md-6 col-lg-8 display-6" style="text-align: center; font-size:20px">
          KeyBoard Class Level - 1
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row mb-5 mt-3">
        <div class="col mt-5 col-sm-2 col-md-6 col-lg-8 display-6" style="text-align:center; font-size:20px">
          KeyBoard Class Level - 2
        </div>
        <div class="col col-sm-2 col-md-6 col-lg-4 d-flex d-flex-end">
          <img src="C:\xampp\htdocs\M_academy\view-piano-guitar-musical-instruments-store.jpg"
            style="width: 300px;  height: 180px;">
        </div>
      </div>
    </div>

    <div class="container-fluid">
      <div class="row pb-5">
        <div class="col col-sm-2 col-md-6 col-lg-4 d-flex d-flex-start">
          <img src="C:\xampp\htdocs\M_academy\view-piano-guitar-musical-instruments-store.jpg"
            style="width: 300px;  height: 180px;">
        </div>
        <div class="col mt-5 col-sm-2 col-md-6 col-lg-8 display-6" style="text-align:center; font-size:20px">
          KeyBoard Class Level - 3
        </div>
      </div>
    </div>
  </div>  -->


    <!--Demo class -->

  <!-- //Model 1 
  
    <div class="conatiner container-fluid bg-light" style="width: auto; height: auto;">         
    <h1 style="color: rgb(68, 71, 99);">Demo Classes</h1>
    <ul class="list-group list-group-horizontal justify-content-center pb-5">
      <li href="" class="list-group-item list-group-item-action border border-0"> KeyBoard Demo Classes 
        <span class="badge bg-danger rounded-pill ms-2">Free</span>
      </li>
      <li href="" class="list-group-item list-group-item-action border border-0"> Flute Demo Classes
        <span class="badge bg-danger rounded-pill ms-2">Free</span>
      </li>
    </ul>
  </div>   -->

    <!--contact us-->

  <!--             //Model 1
  <div class="container-fluid text text-white" style="background-color: rgb(68, 71, 99);">
    <h1>Contact Us</h1>
    <div class="conatiner container-fluid " style="width: 70%; height: 50%;background-color: #ecebeb;">
      <form action="">
        <div class="form-group">
          <label for="=email" class="text text-dark text-md-2">Name:</label>
          <input type="email" class="form-control" id="email">
        </div>
        <div class="form-group">
          <label for="pwd" class="text text-dark text-md-2">Email address:</label>
          <input type="password" class="form-control" id="pwd">
        </div>
        <button type="submit" class="btn btn-default bg-secondary m-3">Submit</button>
      </form>
    </div>

  </div>
-->

  <!--
     <p class="d-flex ms-4 d-flex-center">Mara Music Academy</p>

         <nav class="navbar navbar-expand-sm bg-light navbar-light ">
        <div class="container-fluid">
            <img src="C:\xampp\htdocs\M_academy\saxophone.png" alt="Logo" style="width:40px; height: 40px;" class="d-flex d-flex-start">
           
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav ms-auto ms-auto-4">
                    <li class="nav-item">
                        <a class="nav-link" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Courses</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Student Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact Info</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
-->


